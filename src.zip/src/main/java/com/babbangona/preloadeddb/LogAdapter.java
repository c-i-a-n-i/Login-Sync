package com.babbangona.preloadeddb;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ciani on 12/03/2018.
 */
public class LogAdapter extends ArrayAdapter<Logs> {
    public LogAdapter(Context context, ArrayList<Logs> logs) {
        super(context, 0, logs);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Logs log = getItem(position);
        if(convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.log_view, parent, false);
            //change the background of recall logs to gray
            if(log.getAction() == Logs.Action.RECALL){convertView.setBackgroundColor(Color.GRAY);}
        }
        //gets handles for each view object in the convertView layout
        TextView tvTime = (TextView) convertView.findViewById(R.id.tvTime);
        TextView tvDate = (TextView) convertView.findViewById(R.id.tvDate);
        TextView tvStatus = (TextView) convertView.findViewById(R.id.tvStatus);
        TextView tvMsg = (TextView) convertView.findViewById(R.id.tvMsg);


        //switch statement that changes the color of each convertView log based on the log status
        switch (log.getStatus())
        {
            case UNUPLOADED:
                tvStatus.setTextColor(Color.RED);
                break;
            case UPLOADED:
                tvStatus.setTextColor(Color.BLUE);
                break;
            case PROCESSED:
                tvStatus.setTextColor(Color.GREEN);
                break;
         }

        //setting the time, date, status and message of the convertView to that of the log
        tvTime.setText(log.getTime());
        tvDate.setText(log.getDate());
        tvStatus.setText(log.getStatus().name());//.name() converts the enum to a string
        tvMsg.setText(log.getMessage());

        return convertView;
    }

}

