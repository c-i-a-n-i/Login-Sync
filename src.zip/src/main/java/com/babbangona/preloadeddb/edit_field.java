package com.babbangona.preloadeddb;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Date;
import java.sql.Time;

public class edit_field extends AppCompatActivity {
    AutoCompleteTextView acSeason1;
    AutoCompleteTextView acSeason2;
    AutoCompleteTextView acIK1;
    AutoCompleteTextView acMem1;
    AutoCompleteTextView acIK2;
    AutoCompleteTextView acMem2;
    AutoCompleteTextView acFld1;
    AutoCompleteTextView acFld2;
    EditText etSize;
    EditText etLat;
    EditText etLong;
    Spinner spCrop;
    Spinner spCropType;
    Spinner spSeed;
    TextView tvSize;
    TextView tvLat;
    TextView tvLong;
    TextView tvCrop;
    TextView tvCropType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_field);

        acSeason1 = (AutoCompleteTextView) findViewById(R.id.acSeason1);    acSeason1.setText("R18");
        acSeason2 = (AutoCompleteTextView) findViewById(R.id.acSeason2);    acSeason2.setText("R18");
        acIK1 = (AutoCompleteTextView) findViewById(R.id.acIK1);
        acIK2 = (AutoCompleteTextView) findViewById(R.id.acIK2);
        acMem1 = (AutoCompleteTextView) findViewById(R.id.acMem1);
        acMem2 = (AutoCompleteTextView) findViewById(R.id.acMem2);
        acFld1 = (AutoCompleteTextView) findViewById(R.id.acFld1);
        acFld2 = (AutoCompleteTextView) findViewById(R.id.acFld2);
        etSize = (EditText) findViewById(R.id.etSize);
        etLat = (EditText) findViewById(R.id.etLat);
        etLong = (EditText) findViewById(R.id.etLong);
        spCrop = (Spinner) findViewById(R.id.spCrop);
        spCropType = (Spinner) findViewById(R.id.spCropType);
        spSeed = (Spinner) findViewById(R.id.spSeed);
        tvSize = (TextView) findViewById(R.id.tvSize);
        tvLat = (TextView) findViewById(R.id.tvLat);
        tvLong = (TextView) findViewById(R.id.tvLong);
        tvCrop = (TextView) findViewById(R.id.tvCrop);
        tvCropType = (TextView) findViewById(R.id.tvCropType);


        //onclicklisteners for the first line of autocomplete text views that refresh their options based on previously selected fields
        String[] seasons = {"R17", "R18", "R19"};   //list of possible seasons
        ArrayAdapter<String> adapter = new ArrayAdapter<> (this,android.R.layout.simple_list_item_1,seasons);   //array adapter for acSeason1
        acSeason1.setAdapter(adapter);

                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                ArrayAdapter<String> adapter1 = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getIKs(acSeason1.getText().toString()));
                acIK1.setAdapter(adapter1);
                //setting OnItemClickListener for acSeason1 to refresh the values to be displayed in acMem1
                acIK1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                        ArrayAdapter<String> adapter = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getMembers(acSeason1.getText().toString(), acIK1.getText().toString()));
                        acMem1.setAdapter(adapter);
                        //setting OnItemClickListener for acMem1 to refresh the values to be displayed in acFld1
                        acMem1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                                ArrayAdapter<String> adapter = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getFields(acSeason1.getText().toString(), acIK1.getText().toString(), acMem1.getText().toString()));
                                acFld1.setAdapter(adapter);
                            }
                        });

                    }
                });

        //onclicklisteners for the second line of autocomplete text views that refresh their options based on previously selected fields
        //same exact operations as the above but for the second line to confirm the entered values
        acSeason2.setAdapter(adapter);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getIKs(acSeason2.getText().toString()));
        acIK2.setAdapter(adapter2);
        acIK2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                ArrayAdapter<String> adapter2 = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getMembers(acSeason2.getText().toString(), acIK2.getText().toString()));
                acMem2.setAdapter(adapter2);
                //setting text changed listeners instead of onitemselected listeners so that values can be loaded into Fld1 without selecting any of the choices
                acMem2.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                        if(editable.length() == 2)
                        {
                            FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                            ArrayAdapter<String> adapter = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getFields(acSeason2.getText().toString(), acIK2.getText().toString(), acMem2.getText().toString()));
                            acFld2.setAdapter(adapter);
                            //on text changed listener for the fld, checks if the 2 IDs are equal and acts appropriately
                            acFld2.addTextChangedListener(new TextWatcher() {
                                @Override
                                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                                }

                                @Override
                                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                                }

                                @Override
                                public void afterTextChanged(Editable editable) {
                                    if(editable.length() == 2)
                                    {
                                        Log.i("CLICKED", "Fld2 clicked");
                                        //checks the two IDs, if not equal, toasts "IDs do not tally, check and try again" if equal
                                        //sets the various textviews to display relevant information
                                        String IK1 = acSeason1.getText().toString() + acIK1.getText().toString() + acMem1.getText().toString() + acFld1.getText().toString();
                                        String IK2 = acSeason2.getText().toString() + acIK2.getText().toString() + acMem2.getText().toString() + acFld2.getText().toString();
                                        if(!IK1.equals(IK2))
                                        {
                                            Toast.makeText(edit_field.this, "IDs do not tally, check and try again", Toast.LENGTH_LONG).show();
                                        }
                                        else
                                        {
                                            String season = acSeason2.getText().toString();
                                            String IK = acIK2.getText().toString();
                                            String member = acMem2.getText().toString();
                                            String field = acFld2.getText().toString();

                                            FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                                            tvSize.setText(fldDB.getSize(season, IK, member, field));
                                            tvCrop.setText(fldDB.getCrop(season, IK, member, field));
                                            tvCropType.setText(fldDB.getCropType(season, IK, member, field));
                                            tvLat.setText(fldDB.getLat(season, IK, member, field));
                                            tvLong.setText(fldDB.getLong(season, IK, member, field));
                                        }

                                    }

                                }
                            });
                        }

                    }
                });

            }
        });

        //setting adapter for the crop
        String[] crops = {" ","Maize", "Rice"}; //the space in front is to make the spinner display a blank in default
        ArrayAdapter<String> adapter3 = new ArrayAdapter<> (this,android.R.layout.simple_list_item_1,crops);
        spCrop.setAdapter(adapter3);
        //setting adapter for the crop type
        spCrop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String[] maizeTypes = {" ", "SM-15", "PVA-8"};
                String[] riceTypes = {" ", "Faro 44", "Faro 56", "Faro 61"};
                switch(adapterView.getItemAtPosition(i).toString())
                {
                    case "Maize":
                        ArrayAdapter<String> adapter3 = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, maizeTypes);
                        spCropType.setAdapter(adapter3);
                        break;
                    case "Rice":
                        ArrayAdapter<String> adapter4 = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, riceTypes);
                        spCropType.setAdapter(adapter4);
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //setting adapter for the seed farm
        String[] yesOrno = {" ", "yes", "no"};
        ArrayAdapter<String> adapter4 = new ArrayAdapter<> (this,android.R.layout.simple_list_item_1,yesOrno);
        spSeed.setAdapter(adapter4);

    }

    public void editFld_onClick(View v)
    {
        String IK1 = acSeason1.getText().toString() +"-"+ acIK1.getText().toString() +"-"+ acMem1.getText().toString() +"-"+ acFld1.getText().toString();
        String IK2 = acSeason2.getText().toString() +"-"+ acIK2.getText().toString() +"-"+ acMem2.getText().toString() +"-"+ acFld2.getText().toString();
        final String IK = acIK1.getText().toString();
        final String mem = acMem1.getText().toString();
        final String fld = acFld1.getText().toString();
        final String lon = etLong.getText().toString();
        final String lat = etLat.getText().toString();
        final String size = etSize.getText().toString();

        //Checks if the two IKs entered are equal
        if(!IK1.equals(IK2))
        {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return;
        }

        //checks if there are any empty input fields
        if(IK.equals("") || mem.equals("") || fld.equals("") || spCrop.getSelectedItem() == null || spCropType.getSelectedItem() == null|| lon.equals("") || lat.equals("") || size.equals("")|| spSeed.getSelectedItem() == null)
        {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return;
        }
        //these are declared after the above if block because otherwise if crop or cropType is empty/null, it will give an error if toString() is called on it
        final String crop = spCrop.getSelectedItem().toString();
        final String cropType = spCropType.getSelectedItem().toString();
        final String seed = spSeed.getSelectedItem().toString();

        //checks if the confirmed field exists
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if(!db.fieldExists(acIK1.getText().toString(), acMem1.getText().toString(), acFld1.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK1 + "  does not exist in the database", Toast.LENGTH_LONG).show();
            return;
        }

        //Alert dialog that asks if the user is sure of his action
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Edit Field");
        builder1.setMessage("Are you sure you want to edit field " + IK1 + "?");
        builder1.setIcon(android.R.drawable.ic_dialog_alert);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //getting current date and time and using them to initialize the log object
                        Date date = new Date(System.currentTimeMillis());
                        Time time = new Time(System.currentTimeMillis());
                        Logs log = new Logs(time.toString(),date.toString());

                        log.edit_field(IK, mem, fld, crop, cropType, seed, lon, lat);
                        LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
                        db.onAdd(log);
                        db.close();
                        Toast.makeText(getApplicationContext(), "Field scheduled for editing", Toast.LENGTH_LONG).show();
                        dialog.cancel();
                        Intent intent = new Intent(getApplicationContext(), MIK.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert = builder1.create();
        alert.show();

    }
    public boolean validInputs()
    {
        String IK1 = acSeason1.getText().toString() +"-"+ acIK1.getText().toString() +"-"+ acMem1.getText().toString() +"-"+ acFld1.getText().toString();
        String IK2 = acSeason2.getText().toString() +"-"+ acIK2.getText().toString() +"-"+ acMem2.getText().toString() +"-"+ acFld2.getText().toString();
        final String IK = acIK1.getText().toString();
        final String mem = acMem1.getText().toString();
        final String fld = acFld1.getText().toString();

        //Checks if the two IKs entered are equal
        if(!IK1.equals(IK2))
        {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return false;
        }

        //checks if there are any empty input fields
        if(IK.equals("") || mem.equals("") || fld.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return false;
        }

        //checks if the confirmed field exists
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if(!db.fieldExists(acIK1.getText().toString(), acMem1.getText().toString(), acFld1.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK1 + "  does not exist in the database", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    public void refresh_onClick(View v)
    {
        if(validInputs())
        {
            //refresh
            String season = acSeason1.getText().toString();
            String IK = acIK1.getText().toString();
            String member = acMem1.getText().toString();
            String field = acFld1.getText().toString();
            FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
            tvSize.setText(fldDB.getSize(season, IK, member, field));
            tvCrop.setText(fldDB.getCrop(season, IK, member, field));
            tvCropType.setText(fldDB.getCropType(season, IK, member, field));
            tvLat.setText(fldDB.getLat(season, IK, member, field));
            tvLong.setText(fldDB.getLong(season, IK, member, field));
            Log.i("SUCCESS", "Text refreshed");
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Invalid inputs, check input fields and try again", Toast.LENGTH_LONG).show();
        }

    }
}
