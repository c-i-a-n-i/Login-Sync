package com.babbangona.preloadeddb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ciani on 18/03/2018.
 */
public class LogDBhandlerES extends SQLiteOpenHelper{
    private static final String database = "LOGS_2.db";
    private static final String table = "Log2";
    private static final String idonline = "idonline";
    private static final String timestamp = "timestamp";
    private static final String user = "user";
    private static final String message = "message";
    private static final String status = "status";
    private static final String entity = "entity";
    private static final String action = "action";
    private static final String syncStatus = "syncStatus";
    private static final String updateStatus = "updateStatus";
    private static final String time = "time";
    private static final String date = "date";

    public LogDBhandlerES(Context context, SQLiteDatabase.CursorFactory factory) {
        super(context, database, factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create = "create table " + table + "(" + "id integer primary key autoincrement not null, "
                + idonline + " text, "
                + timestamp + " timestamp, "
                + user + " user, "
                + message + " text, "
                + status + " text, "
                + entity + " text, "
                + action + " text, "
                + time + " text, "
                + date + " text, "
                + syncStatus + " text, "
                + updateStatus + " text);";

        sqLiteDatabase.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop if table exists "+ table);
        onCreate(sqLiteDatabase);
    }

    public void onAdd(String idonline, String timestamp, String user, String message, String status, String entity, String action, String time, String date, String syncStatus, String updateStatus)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("idonline", idonline);
        values.put("timestamp", timestamp);
        values.put("user", user);
        values.put("message", message);
        values.put("status", status);
        values.put("entity", entity);
        values.put("action", action);
        values.put("time", time);
        values.put("date", date);
        values.put("syncStatus", syncStatus);
        values.put("updateStatus", updateStatus);

        db.insert(table, null, values);
        db.close();
        Log.i("SUCCESS", "Log Added to local db");

    }

    //function that populates the array list that populates our array adapter. The function can be edited to display filtered or sorted values
    //based on status, entity and co. This can be done by adjusting the sql query "all" appropriately
    public ArrayList<Logs> displayByTimestamp()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), c.getString(c.getColumnIndex("user")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByField()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"FIELD\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByMember()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"MEMBER\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByTG()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"TG\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByAddtions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"ADD\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByEditions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"EDIT\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByDeletions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"DELETE\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByMerges()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"MERGE\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByRecalls()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"RECALL\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByUnuploaded()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"UNUPLOADED\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByUploaded()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"UPLOADED\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByProcessed()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"PROCESSED/\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public void onStatusUpdate(Logs log, String status)
    {
        SQLiteDatabase db = getWritableDatabase();
        String update = "update " + table + " set status = \"" + status + "\" where message = \"" + log.getMessage() + "\"";
        db.execSQL(update);
        db.close();

    }
    /*
    *
    * ONLINE DB FUNCTIONS BEGIN HERE
    *
    *
    *
    */


    public void updateUpdateStatus(String idonline, String updateStatus){
        String updateQuery = "update " + table + " set updateStatus = '"+ updateStatus +"', status = 'UPLOADED' where idonline = "+ idonline;
        Log.d("query", updateQuery);
        getReadableDatabase().execSQL(updateQuery);
    }

    public ArrayList<HashMap<String, String>> getAllUpdatedLogs(){
        ArrayList<HashMap<String, String>> wordList = new ArrayList<>();
        String selectQuery = "select * from " + table + " where status = 'PROCESSED'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);

        if(cursor.getCount() < 1){ return wordList;}

        cursor.moveToFirst();
        do
        {
            HashMap<String, String> map = new HashMap<>();
            map.put("idonline", cursor.getString(cursor.getColumnIndex("idonline")));
            wordList.add(map);
        }while (cursor.moveToNext());
        cursor.close();

        return wordList;
    }


    public String composeJSONfromSQLite()
    {
        ArrayList<HashMap<String, String>> unsynced = this.getAllUpdatedLogs();
        Gson gson = new GsonBuilder().create();
        Log.i("SUCCESS","JSON composed "+ gson.toJson(unsynced));
        return gson.toJson(unsynced);
    }


}
