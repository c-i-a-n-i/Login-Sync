package com.babbangona.preloadeddb;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import java.sql.Date;
import java.sql.Time;

public class delete_TG extends AppCompatActivity {
    AutoCompleteTextView acIK1;
    AutoCompleteTextView acIK2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete__tg);

        acIK1 = (AutoCompleteTextView) findViewById(R.id.acIK1);
        acIK2 = (AutoCompleteTextView) findViewById(R.id.acIK2);
        FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
        ArrayAdapter<String> adapter = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getIKs("R18"));
        acIK1.setAdapter(adapter);
        acIK2.setAdapter(adapter);
    }

    public void delTG_onClick(View v)
    {
        final String IK1 = acIK1.getText().toString();
        final String IK2 = acIK2.getText().toString();
        //checks if the IKs are equal
        if(!IK1.equals(IK2))
        {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if IKs have been entered
        if(IK1.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return;
        }
        //checks if the confirmed IK exist
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if(!db.IKExists(acIK1.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK1 + " does not exist in the database", Toast.LENGTH_LONG).show();
            return;
        }

        //Alert dialog that asks if the user is sure of his action
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Delete Trust Group");
        builder1.setMessage("Are you sure you want to delete TG " + IK1 + "?");
        builder1.setIcon(android.R.drawable.ic_dialog_alert);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //getting current date and time and using them to initialize the log object
                        Date date = new Date(System.currentTimeMillis());
                        Time time = new Time(System.currentTimeMillis());
                        Logs log = new Logs(time.toString(),date.toString());

                        log.delete_TG(IK1);
                        LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
                        db.onAdd(log);
                        db.close();
                        Toast.makeText(getApplicationContext(), "TG scheduled to be deleted", Toast.LENGTH_LONG).show();
                        dialog.cancel();
                        Intent intent = new Intent(getApplicationContext(), MIK.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert = builder1.create();
        alert.show();
    }
}
