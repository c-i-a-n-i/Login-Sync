package com.babbangona.preloadeddb;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class modifyTG extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_tg);

    }
    public void mergeTG(View v)
    {
        Intent intent = new Intent(getApplicationContext(), merge_TG.class);
        startActivity(intent);
    }
    public void deleteTG(View v)
    {
        Intent intent = new Intent(getApplicationContext(), delete_TG.class);
        startActivity(intent);
    }
}
