package com.babbangona.preloadeddb;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class modifyMembers extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_members);

    }

    public void addMem(View v)
    {
        Intent intent = new Intent(getApplicationContext(), add_member.class);
        startActivity(intent);
    }
    public void editMem(View v)
    {
        Intent intent = new Intent(getApplicationContext(), edit_member.class);
        startActivity(intent);
    }
    public void deleteMem(View v)
    {
        Intent intent = new Intent(getApplicationContext(), delete_member.class);
        startActivity(intent);
    }
}
