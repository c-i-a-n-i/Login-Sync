package com.babbangona.preloadeddb;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import java.sql.Date;
import java.sql.Time;

public class merge_TG extends AppCompatActivity {
    AutoCompleteTextView acIK1;
    AutoCompleteTextView acIK2;
    AutoCompleteTextView acIK12;
    AutoCompleteTextView acIK22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merge__tg);

        acIK1 = (AutoCompleteTextView) findViewById(R.id.acIK1);
        acIK2 = (AutoCompleteTextView) findViewById(R.id.acIK2);
        acIK12 = (AutoCompleteTextView) findViewById(R.id.acIK12);
        acIK22 = (AutoCompleteTextView) findViewById(R.id.acIK22);

        FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
        ArrayAdapter<String> adapter = new ArrayAdapter<> (getApplicationContext(),android.R.layout.simple_list_item_1, fldDB.getIKs("R18"));
        acIK1.setAdapter(adapter);
        acIK2.setAdapter(adapter);
        acIK12.setAdapter(adapter);
        acIK22.setAdapter(adapter);

    }

    public void mrgTG_onClick(View v)
    {
        final String IK1 = acIK1.getText().toString();
        final String IK2 = acIK2.getText().toString();
        final String IK3 = acIK12.getText().toString();
        final String IK4 = acIK22.getText().toString();

        //Checks if the two IKs entered are equal
        if((!IK1.equals(IK3)) || (!IK2.equals(IK4)))
        {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return;
        }

        //checks if there are any empty input fields
        if(IK1.equals("") || IK2.equals("")|| IK3.equals("")||IK4.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return;
        }

        //checks if IKs to be merged are the same
        if(IK1.equals(IK2))
        {
            Toast.makeText(getApplicationContext(), "Cannot merge the same trust group", Toast.LENGTH_LONG).show();
            return;
        }

        //checks if the confirmed IKs exist
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if(!db.IKExists(acIK1.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK1 + " does not exist in the database", Toast.LENGTH_LONG).show();
            return;
        }
        if(!db.IKExists(acIK2.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK2 + " does not exist in the database", Toast.LENGTH_LONG).show();
            return;
        }

        //Alert dialog that asks if the user is sure of his action
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Merge Trust Groups");
        builder1.setMessage("Are you sure you want to merge TGs " + IK1 + " and " + IK2 + "?");
        builder1.setIcon(android.R.drawable.ic_dialog_alert);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //getting current date and time and using them to initialize the log object
                        Date date = new Date(System.currentTimeMillis());
                        Time time = new Time(System.currentTimeMillis());
                        Logs log = new Logs(time.toString(),date.toString());

                        log.merge_TG(IK1, IK2);
                        LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
                        db.onAdd(log);
                        db.close();
                        Toast.makeText(getApplicationContext(), "TGs scheduled to be merged", Toast.LENGTH_LONG).show();
                        dialog.cancel();
                        Intent intent = new Intent(getApplicationContext(), MIK.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert = builder1.create();
        alert.show();
    }
}
