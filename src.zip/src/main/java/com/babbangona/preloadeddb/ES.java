package com.babbangona.preloadeddb;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ES extends AppCompatActivity {
    TextView tvWelcome;
    String name;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_es);

        prefs = getSharedPreferences("Preferences", MODE_PRIVATE);

        name = prefs.getString("username", " ");    //gets the set preference, returns space if preference is not yet set

        //Sets welcome message
        tvWelcome = (TextView) findViewById(R.id.tvWelcome);
        tvWelcome.setText("Welcome " + name + " !");
    }

    @Override
    public void onBackPressed()
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void logs(View view)
    {
        Intent intent = new Intent(getApplicationContext(), viewLogsES.class);
        startActivity(intent);
    }
}
