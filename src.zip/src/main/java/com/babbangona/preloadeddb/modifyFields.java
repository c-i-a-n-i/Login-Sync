package com.babbangona.preloadeddb;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class modifyFields extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_fields);

    }
    public void addFld(View v)
    {
        Intent intent = new Intent(getApplicationContext(), add_field.class);
        startActivity(intent);
    }
    public void editFld(View v)
    {
        Intent intent = new Intent(getApplicationContext(), edit_field.class);
        startActivity(intent);
    }
    public void deleteFld(View v)
    {
        Intent intent = new Intent(getApplicationContext(), delete_field.class);
        startActivity(intent);
    }
}
