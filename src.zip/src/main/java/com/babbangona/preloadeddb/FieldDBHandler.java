package com.babbangona.preloadeddb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;

/**
 * Created by ciani on 08/03/2018.
 */
public class FieldDBHandler extends SQLiteAssetHelper {
    final static String dbName = "fld_mem.db";
    final static int version = 1;

    public FieldDBHandler(Context context) {
        super(context, dbName, null, version);
    }



    public ArrayList<String> getIKs(String season)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select ik_number from fields where season_id = \""+ season +"\" group by ik_number";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<String> IKs = new ArrayList<>();

        if(c.getCount() < 1){ return IKs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            IKs.add(c.getString(c.getColumnIndex("ik_number")));
        }while(c.moveToNext());

        c.close();
        db.close();

        return IKs;

    }

    public ArrayList<String> getMembers(String season, String IK)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select member_id from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" group by member_id";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<String> IKs = new ArrayList<>();

        if(c.getCount() < 1){ return IKs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            IKs.add(c.getString(c.getColumnIndex("member_id")));
        }while(c.moveToNext());

        c.close();
        db.close();

        return IKs;

    }

    public ArrayList<String> getFields(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select field_id from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" ";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<String> fields = new ArrayList<>();

        if(c.getCount() < 1){ return fields;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            fields.add(c.getString(c.getColumnIndex("field_id")));
        }while(c.moveToNext());

        c.close();
        db.close();

        return fields;

    }

    public String getSize(String season, String IK, String member, String field)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" and field_id = \"" + field +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("size"));
        c.close();
        db.close();

        return size;

    }

    public String getCrop(String season, String IK, String member, String field)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" and field_id = \"" + field +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String crop = " ";

        if(c.getCount() < 1){ return crop;} //makes sure a null cursor is not passed to the get size function below

        crop = c.getString(c.getColumnIndex("crop"));
        c.close();
        db.close();

        return crop;

    }


    public String getCropType(String season, String IK, String member, String field)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" and field_id = \"" + field +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("crop_type"));
        c.close();
        db.close();

        return size;

    }

    public String getLat(String season, String IK, String member, String field)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" and field_id = \"" + field +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("latitude"));
        c.close();
        db.close();

        return size;

    }

    public String getLong(String season, String IK, String member, String field)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\" and field_id = \"" + field +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("longitude"));
        c.close();
        db.close();

        return size;

    }

    public String getName(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("first_name")) + " " + c.getString(c.getColumnIndex("last_name"));
        c.close();
        db.close();

        return size;

    }

    public String getAge(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("birthday"));
        c.close();
        db.close();

        return size;

    }

    public String getVillage(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("village"));
        c.close();
        db.close();

        return size;

    }

    public String getSex(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("sex"));
        c.close();
        db.close();

        return size;

    }

    public String getPhone(String season, String IK, String member)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members where season_id = \""+ season +"\" and ik_number = \"" + IK +"\" and member_id = \"" + member +"\"";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        String size = " ";

        if(c.getCount() < 1){ return size;} //makes sure a null cursor is not passed to the get size function below

        size = c.getString(c.getColumnIndex("phone"));
        c.close();
        db.close();

        return size;

    }

    public boolean  IKExists(String IK) {
        SQLiteDatabase sqldb = getWritableDatabase();
        String Query = "select * from fields where ik_number = " + "'" + IK + "'";
        Cursor cursor = sqldb.rawQuery(Query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    public boolean  memberExists(String IK, String mem) {
        SQLiteDatabase sqldb = getWritableDatabase();
        String Query = "select * from fields where ik_number = " + "'" + IK + "' and member_id = " + "'" + mem + "'";
        Cursor cursor = sqldb.rawQuery(Query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }
    public boolean  fieldExists(String IK, String mem, String fld) {
        SQLiteDatabase sqldb = getWritableDatabase();
        String Query = "select * from fields where ik_number = " + "'" + IK + "' and member_id = " + "'" + mem + "' and field_id = " + "'" + fld + "'";
        Cursor cursor = sqldb.rawQuery(Query, null);
        if(cursor.getCount() <= 0){
            cursor.close();
            return false;
        }
        cursor.close();
        return true;
    }

    public void fieldsAdd(String id, String season_id, String timestamp, String ik_number, String member_id, String field_id, String size, String crop, String crop_type, String latitude, String longitude)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", id);
        values.put("timestamp", timestamp);
        values.put("season_id", season_id);
        values.put("ik_number", ik_number);
        values.put("member_id", member_id);
        values.put("field_id", field_id);
        values.put("size", size);
        values.put("crop", crop);
        values.put("crop_type", crop_type);
        db.insert("fields", null, values);
        db.close();

    }
    public void membersAdd(String id, String season_id, String timestamp, String ik_number, String member_id, String first_name, String last_name, String sex, String birthday, String village, String phone)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", id);
        values.put("timestamp", timestamp);
        values.put("season_id", season_id);
        values.put("ik_number", ik_number);
        values.put("member_id", member_id);
        values.put("first_name", first_name);
        values.put("last_name", last_name);
        values.put("sex", sex);
        values.put("birthday", birthday);
        values.put("village", village);
        values.put("phone", phone);
        db.insert("members", null, values);
        db.close();

    }

    public String latestMemUpdate()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from members order by timestamp desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        if(c.getCount() < 1){ return "0";} //makes sure a null cursor is not passed to the get size function below

        String lastUpdated = c.getString(c.getColumnIndex("timestamp"));
        c.close();
        db.close();

        return lastUpdated;

    }

    public String latestFldUpdate()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from fields order by timestamp desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        if(c.getCount() < 1){ return "0";} //makes sure a null cursor is not passed to the get size function below

        String lastUpdated = c.getString(c.getColumnIndex("timestamp"));
        c.close();
        db.close();

        return lastUpdated;

    }
}
