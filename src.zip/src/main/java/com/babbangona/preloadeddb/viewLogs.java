package com.babbangona.preloadeddb;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;

public class viewLogs extends AppCompatActivity {
    private LogAdapter logAdapter;
    private ListView listView;
    SharedPreferences prefs;
    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_logs);

        listView = (ListView) findViewById(R.id.listView);

        prefs = getSharedPreferences("Preferences", MODE_PRIVATE);
        user = prefs.getString("username"," ");

        //using the database to populate the list view
        LogDBhandler db = new LogDBhandler(this, null);
        logAdapter = new LogAdapter(this,db.displayByTimestamp());
        listView.setAdapter(logAdapter);


        //displaying alert dialog for recall function
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                final Logs orglog = (Logs) listView.getAdapter().getItem(i);
                AlertDialog.Builder builder1 = new AlertDialog.Builder(viewLogs.this);
                builder1.setTitle("Recall log");
                builder1.setMessage("Are you sure you want to recall this log?");
                builder1.setIcon(android.R.drawable.ic_dialog_alert);
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //getting current date and time and using them to initialize the log object
                                Date date = new Date(System.currentTimeMillis());
                                Time time = new Time(System.currentTimeMillis());
                                Logs log = new Logs(time.toString(),date.toString());

                                log.recall(orglog);
                                LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
                                db.onAdd(log);
                                db.close();
                                Toast.makeText(getApplicationContext(), "Log scheduled to be recalled", Toast.LENGTH_LONG).show();
                                dialog.cancel();
                                Intent intent = new Intent(getApplicationContext(), MIK.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert = builder1.create();
                alert.show();
                return false;
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MIK.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LogDBhandler db = new LogDBhandler(this, null);
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch(item.getItemId()){
            case R.id.itmAdditions:
                logAdapter = new LogAdapter(this,db.displayByAddtions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Additions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmEditions:
                logAdapter = new LogAdapter(this,db.displayByEditions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Editions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmDeletions:
                logAdapter = new LogAdapter(this,db.displayByDeletions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Deletions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmMerges:
                logAdapter = new LogAdapter(this,db.displayByMerges());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Merges", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmMembers:
                logAdapter = new LogAdapter(this,db.displayByMember());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Member actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmFields:
                logAdapter = new LogAdapter(this,db.displayByField());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Field actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmTGs:
                logAdapter = new LogAdapter(this,db.displayByTG());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "TG actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmUnuploaded:
                logAdapter = new LogAdapter(this,db.displayByUnuploaded());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Unuploaded actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmProcessed:
                logAdapter = new LogAdapter(this,db.displayByProcessed());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Processed actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmUploaded:
                logAdapter = new LogAdapter(this,db.displayByUploaded());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Uploaded actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmRecalls:
                logAdapter = new LogAdapter(this,db.displayByRecalls());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Recalled actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmRefresh:
                ProgressDialog pd = ProgressDialog.show(this, null,"Loading");
                memberUpdate();
                fieldUpdate();
                mikupload();
                mikupdate();
                pd.dismiss();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    public void mikupload()
    {
        final LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
        ArrayList<HashMap<String, String>> logs = db.getAllLogs();
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        if (logs.size() != 0) {
            if (db.dbSyncCount() != 0) {
                params.put("unsyncedJSON", db.composeJSONfromSQLite());
                client.post("http://apps.babbangona.com/tg_restructuring/mikupload.php", params, new AsyncHttpResponseHandler(){
                    @Override
                    public void onSuccess(String response) {
                        Log.i("SUCCESS","onSuccess entered");
                        try {
                            JSONArray arr = new JSONArray(response);
                            System.out.println(arr.length());
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject obj = (JSONObject) arr.get(i);
                                Log.i("SUCCESS",obj.get("id") + " " + obj.get("status"));
                                db.updateSyncStatus(obj.get("id").toString(), obj.get("status").toString());
                            }
                            Intent intent = new Intent(getApplicationContext(), viewLogs.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            //Toast.makeText(getApplicationContext(), "DB Sync completed! ", Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            //Toast.makeText(getApplicationContext(), "Error occurred [Server's JSON response might be invalid]!", Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onFailure(int statusCode, Throwable error, String content) {
                        Toast.makeText(getApplicationContext(), "Server might be offline ", Toast.LENGTH_LONG).show();

                        if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                        else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                        else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
                    }

                });

            } else {  Toast.makeText(getApplicationContext(), "SQLite and Remote MySQL DBs are in Sync!", Toast.LENGTH_LONG).show();}

        } else { Toast.makeText(getApplicationContext(), "There are no logs in local db!", Toast.LENGTH_LONG).show();}
    }

    public void mikupdate()
    {
        final LogDBhandler db = new LogDBhandler(getApplicationContext(), null);

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("user", user);
        ArrayList<HashMap<String, String>> logs = db.getAllLogs();

        if(logs.size()!= 0)
        {
            client.post("http://apps.babbangona.com/tg_restructuring/mikupdate.php", params, new AsyncHttpResponseHandler(){
                @Override
                public void onSuccess(String response) {
                    try {
                        JSONArray arr = new JSONArray(response);
                        System.out.println(arr.length());
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject obj = (JSONObject) arr.get(i);
                            db.onStatusUpdate(obj.get("id").toString(), obj.get("status").toString());
                        }
                        Intent intent = new Intent(getApplicationContext(), viewLogs.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                        Toast.makeText(getApplicationContext(), "DB Status updated! ", Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        //Toast.makeText(getApplicationContext(), "Local database is up to date!", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Throwable error, String content) {
                    Toast.makeText(getApplicationContext(), "Server might be offline ", Toast.LENGTH_LONG).show();

                    if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                    else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                    else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
                }

            });
        }

    }

    public void fieldUpdate()
    {
        final FieldDBHandler db = new FieldDBHandler(getApplicationContext());

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("lastFldUpdate", db.latestFldUpdate());

        client.post("http://apps.babbangona.com/tg_restructuring/fieldupdate.php", params, new AsyncHttpResponseHandler(){
            @Override
            public void onSuccess(String response) {
                try {
                    JSONArray arr = new JSONArray(response);
                    System.out.println(arr.length());
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = (JSONObject) arr.get(i);

                        db.fieldsAdd(obj.get("id").toString(), obj.get("timestamp").toString(), obj.get("season_id").toString(), obj.get("ik_number").toString(),
                                obj.get("member_id").toString(), obj.get("field_id").toString(), obj.get("size").toString(), obj.get("crop").toString(),
                                obj.get("crop_type").toString(), obj.get("latitude").toString(), obj.get("longitude").toString());
                    }
                    //Toast.makeText(getApplicationContext(), "Field DB updated! ", Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Log.i("SUCCESS", db.latestFldUpdate());
                   // Toast.makeText(getApplicationContext(), "Error caught!", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(int statusCode, Throwable error, String content) {
                //Toast.makeText(getApplicationContext(), "Server might be offline ", Toast.LENGTH_LONG).show();

                if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
            }

        });
    }

    public void memberUpdate()
    {
        final FieldDBHandler db = new FieldDBHandler(getApplicationContext());

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("lastMemUpdate", db.latestMemUpdate());

        client.post("http://apps.babbangona.com/tg_restructuring/memberupdate.php", params, new AsyncHttpResponseHandler(){
            @Override
            public void onSuccess(String response) {
                try {
                    JSONArray arr = new JSONArray(response);
                    System.out.println(arr.length());
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = (JSONObject) arr.get(i);

                        db.membersAdd(obj.get("id").toString(), obj.get("timestamp").toString(), obj.get("season_id").toString(), obj.get("ik_number").toString(),
                                obj.get("member_id").toString(), obj.get("first_name").toString(), obj.get("last_name").toString(),
                                obj.get("sex").toString(), obj.get("birthday").toString(), obj.get("village").toString(), obj.get("phone").toString());
                    }
                    //Toast.makeText(getApplicationContext(), "Member DB updated! ", Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Log.i("SUCCESS", db.latestFldUpdate());
                    //Toast.makeText(getApplicationContext(), "Error caught!", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(int statusCode, Throwable error, String content) {

                if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
            }

        });
    }
}
