package com.babbangona.preloadeddb;

/**
 * Created by ciani on 12/03/2018.
 */
public class Logs {

    private String message;
    private Status status;
    private Entity entity;
    private Action action;
    private String time;
    private String date;
    private String user;

    public enum Status{UNUPLOADED, UPLOADED, PROCESSED}
    public enum Entity{FIELD, MEMBER, TG}
    public enum Action{ADD, DELETE, EDIT, MERGE, RECALL}

    //constructor for MIK logs
    public Logs(String time, String date, Status status, String message, Entity entity, Action action) {
        this.time = time;
        this.date = date;
        this.status = status;
        this.message = message;
        this.entity = entity;
        this.action = action;
    }

    //constructor for ES logs
    public Logs(String time, String date, String user, Status status, String message, Entity entity, Action action) {
        this.time = time;
        this.date = date;
        this.status = status;
        this.message = message;
        this.entity = entity;
        this.action = action;
        this.user = user;
    }

    public Logs(String time, String date) {
        this.time = time;
        this.date = date;
        this.status = Status.UNUPLOADED;
    }

    public Status getStatus() {
        return status;
    }

    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }

    public String getMessage() {
        return message;
    }

    public Entity getEntity() {
        return entity;
    }

    public Action getAction() {
        return action;
    }

    public String getUser() {
        return user;
    }

    //Function for creating logs for adding members
    public void add_member(String IK, String name, String age, String village, String sex, String phone)
    {
        this.message = "Add " + name + ", a " + age + " year old " + sex + " from " + village + " with phone number " + phone + " to TG " + IK;
        this.action = Action.ADD;
        this.entity = Entity.MEMBER;
    }

    //Function for creating logs for editing members
    public void edit_member(String IK, String memID, String name, String age, String village, String sex, String phone)
    {
        this.message = "Change member " + IK +"-"+ memID + " name to " + name + ", age to " + age + ", sex to " + sex + ", village to " + village + " and phone number to " + phone;
        this.action = Action.EDIT;
        this.entity = Entity.MEMBER;
    }

    //Function for creating logs for deleting members
    public void delete_member(String IK, String memID)
    {
        this.message = "Delete member " + IK + "-" + memID;
        this.action = Action.DELETE;
        this.entity = Entity.MEMBER;
    }
    //Function for creating logs for adding fields
    public void add_field(String IK, String memID, String crop, String cropType, String seed, String lon, String lat)
    {
        this.message = "Add a " + crop + " field of type " + cropType + " with coordinates: latitude " + lat + " and longitude " + lon + " to member " + IK + "-" + memID;
        switch(seed)
        {
            case "yes":
                this.message += ". It is a seed farm";
                break;
            case "no":
                this.message += ". It is not a seed farm";
                break;
        }
        this.action = Action.ADD;
        this.entity = Entity.FIELD;
    }

    //Function for creating logs for editing fields
    public void edit_field(String IK, String memID, String fldID, String crop, String cropType, String seed, String lon, String lat)
    {
        this.message = "Change field " + IK +"-"+ memID +"-"+ fldID + " crop to " + crop + " of " + cropType + " type. Change its longitude to " + lon + ", latitude to " + lat + " and seed farm status to " + seed;
        this.action = Action.EDIT;
        this.entity = Entity.FIELD;
    }

    //Function for creating logs for deleting fields
    public void delete_field(String IK, String memID, String fldID)
    {
        this.message = "Delete field " + IK + "-" + memID + "-" + fldID;
        this.action = Action.DELETE;
        this.entity = Entity.FIELD;
    }

    //Function for creating logs for merging TGs
    public void merge_TG(String IK1, String IK2)
    {
        this.message = "Merge trust groups " + IK1 + " and " + IK2;
        this.action = Action.MERGE;
        this.entity = Entity.TG;
    }

    //Function for creating logs for deleting TGs
    public void delete_TG(String IK1)
    {
        this.message = "Delete trust group " + IK1;
        this.action = Action.DELETE;
        this.entity = Entity.TG;
    }

    //Function for creating logs for recalling logs
    // Will make the member variables equal to those of the Logs object in the parameter list, then change recalled tag to true
    public void recall(Logs log)
    {
        this.message = "Recall log: " + log.getMessage() + " set at time " + log.getTime() + " on " + log.getDate();
        this.entity = log.getEntity();
        this.action = Action.RECALL;

    }
}


