package com.babbangona.preloadeddb;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class viewLogsES extends AppCompatActivity {
    private LogAdapterES logAdapter;
    private ListView listView;
    SharedPreferences prefs;
    String hub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_logs_es);

        listView = (ListView) findViewById(R.id.listView);

        prefs = getSharedPreferences("Preferences", MODE_PRIVATE);
        hub = prefs.getString("hub"," ");


        //using the database to populate the list view
        LogDBhandlerES db = new LogDBhandlerES(this, null);
        logAdapter = new LogAdapterES(this,db.displayByTimestamp());
        listView.setAdapter(logAdapter);

        //displaying alert dialog for status change option
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View view, int i, long l) {
                final Logs log = (Logs) listView.getAdapter().getItem(i);
                final LogDBhandlerES db2 = new LogDBhandlerES(getApplicationContext(), null);

                if(log.getStatus() != Logs.Status.UPLOADED) //if block to prevent the ES from changing the status of an uploaded log
                {
                    dialog(db2, log);
                }


            }
        });
    }


    //function for showing the alert dialog
    public void dialog(final LogDBhandlerES db2, final Logs log)
    {
        String[] statuses = {"UNUPLOADED", "PROCESSED"};
        AlertDialog.Builder builder = new AlertDialog.Builder(viewLogsES.this);

        // Set the dialog title
        builder.setTitle("Mark status as:")

                .setSingleChoiceItems(statuses, 0, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int i) {

                    }

                })

                // Set the action buttons
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // user clicked OK, so save the mSelectedItems results somewhere
                        // or return them to the component that opened the dialog

                        int selectedPosition = ((AlertDialog)dialog).getListView().getCheckedItemPosition();

                        switch(selectedPosition)
                        {
                            case 0:
                                db2.onStatusUpdate(log, "UNUPLOADED");
                                break;
                            case 1:
                                db2.onStatusUpdate(log, "PROCESSED");
                                break;
                        }

                        Toast.makeText(getApplicationContext(),"Status updated", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getApplicationContext(), viewLogsES.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                    }
                })

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // removes the dialog from the screen

                    }
                })

                .show();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LogDBhandlerES db = new LogDBhandlerES(this, null);
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch(item.getItemId()){
            case R.id.itmAdditions:
                logAdapter = new LogAdapterES(this,db.displayByAddtions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Additions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmEditions:
                logAdapter = new LogAdapterES(this,db.displayByEditions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Editions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmDeletions:
                logAdapter = new LogAdapterES(this,db.displayByDeletions());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Deletions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmMerges:
                logAdapter = new LogAdapterES(this,db.displayByMerges());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Merges", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmMembers:
                logAdapter = new LogAdapterES(this,db.displayByMember());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Member actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmFields:
                logAdapter = new LogAdapterES(this,db.displayByField());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Field actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmTGs:
                logAdapter = new LogAdapterES(this,db.displayByTG());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "TG actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmUnuploaded:
                logAdapter = new LogAdapterES(this,db.displayByUnuploaded());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Unuploaded actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmProcessed:
                logAdapter = new LogAdapterES(this,db.displayByProcessed());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Processed actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmUploaded:
                logAdapter = new LogAdapterES(this,db.displayByUploaded());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Uploaded actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmRecalls:
                logAdapter = new LogAdapterES(this,db.displayByRecalls());
                listView.setAdapter(logAdapter);
                Toast.makeText(getApplicationContext(), "Recalled actions", Toast.LENGTH_LONG).show();
                break;
            case R.id.itmRefresh:
                ProgressDialog pd = ProgressDialog.show(this, null,"Loading");
                esdownload();
                esupdate();
                pd.dismiss();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), ES.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void esdownload()
    {
        final LogDBhandlerES db = new LogDBhandlerES(getApplicationContext(), null);

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();
        params.put("hub", hub);

        client.post("http://apps.babbangona.com/tg_restructuring/esdownload.php", params, new AsyncHttpResponseHandler(){
            @Override
            public void onSuccess(String response) {
                try {
                    JSONArray arr = new JSONArray(response);
                    System.out.println(arr.length());
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject obj = (JSONObject) arr.get(i);
                        db.onAdd(obj.get("idonline").toString(), obj.get("timestamp").toString(), obj.get("user").toString(), obj.get("message").toString(), obj.get("status").toString(), obj.get("entity").toString(),
                                obj.get("action").toString(), obj.get("time").toString(), obj.get("date").toString(), obj.get("syncStatus").toString(), obj.get("updateStatus").toString());
                    }
                    Intent intent = new Intent(getApplicationContext(), viewLogsES.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    Toast.makeText(getApplicationContext(), "DB Sync completed! ", Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Error occurred [Server's JSON response might be invalid]!", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

            }
            @Override
            public void onFailure(int statusCode, Throwable error, String content) {
                Toast.makeText(getApplicationContext(), "Server might be offline ", Toast.LENGTH_LONG).show();

                if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
            }

        });
    }

    public void esupdate()
    {
        final LogDBhandlerES db = new LogDBhandlerES(getApplicationContext(), null);

        ArrayList<HashMap<String, String>> logs = db.getAllUpdatedLogs();

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        if (logs.size() != 0) {
            params.put("unupdatedJSON", db.composeJSONfromSQLite());

            client.post("http://apps.babbangona.com/tg_restructuring/esupdate.php", params, new AsyncHttpResponseHandler(){
                @Override
                public void onSuccess(String response) {
                    try {
                        JSONArray arr = new JSONArray(response);
                        System.out.println(arr.length());
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject obj = (JSONObject) arr.get(i);
                            db.updateUpdateStatus(obj.get("idonline").toString(), obj.get("updateStatus").toString());
                        }
                        Intent intent = new Intent(getApplicationContext(), viewLogsES.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);

                        Toast.makeText(getApplicationContext(), "Status updates uploaded! ", Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), "Error occurred couldn't upload updates!", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                }
                @Override
                public void onFailure(int statusCode, Throwable error, String content) {

                    Toast.makeText(getApplicationContext(), "Server might be offline. ", Toast.LENGTH_LONG).show();

                    if (statusCode == 404) {Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();}
                    else if (statusCode == 500) {Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();}
                    else {Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();}
                }

            });

        } else { Toast.makeText(getApplicationContext(), "All updated logs have been uploaded!", Toast.LENGTH_LONG).show();}

    }
}


