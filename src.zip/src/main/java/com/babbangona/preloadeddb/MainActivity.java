package com.babbangona.preloadeddb;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView acUsername;
    EditText etPassword;
    SharedPreferences prefs;
    SharedPreferences.Editor prefsEdit;
    private static final int JOB_ID =101;
    private JobScheduler jobScheduler;
    private JobInfo jobInfo;
    ComponentName componentName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        componentName = new ComponentName(this,NetworkSchedulerService.class);

        acUsername = (AutoCompleteTextView) findViewById(R.id.acUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);

        ArrayAdapter<String> adapter = new ArrayAdapter<> (this,android.R.layout.simple_list_item_1, new DBHandler(getApplicationContext()).getUsers());
        acUsername.setAdapter(adapter);

    }

    public void onDestroy() {
        super.onDestroy();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            componentName = new ComponentName(this,NetworkSchedulerService.class);
            JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
            builder.setMinimumLatency(2000);

            //builder.setTriggerContentMaxDelay(100000);
            builder.setPersisted(true);
            jobInfo = builder.build();
            jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
            jobScheduler.schedule(jobInfo);

        }else{

            JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
            builder.setPeriodic(2000);
            builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
            builder.setPersisted(true);
            jobInfo = builder.build();
            jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
            jobScheduler.schedule(jobInfo);
        }
    }

    public void login_onClick(View view)
    {
        if((!acUsername.getText().toString().isEmpty())&&(!etPassword.getText().toString().isEmpty()))
        {
            final DBHandler db = new DBHandler(this);
            if(db.userExists(acUsername.getText().toString()))
            {
                if(db.password(acUsername.getText().toString()).equals(etPassword.getText().toString()))
                {
                    //using shared preferences to persist the user's name
                    prefs = getSharedPreferences("Preferences", MODE_PRIVATE);
                    prefsEdit = prefs.edit();
                    prefsEdit.putString("username", acUsername.getText().toString());
                    prefsEdit.putString("password", etPassword.getText().toString());
                    prefsEdit.putString("hub", db.hub(acUsername.getText().toString(), etPassword.getText().toString()));
                    prefsEdit.commit();

                    if(!db.logged(acUsername.getText().toString(), etPassword.getText().toString()))
                    {
                        db.updateLogged(acUsername.getText().toString(), etPassword.getText().toString());
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
                        builder.setMinimumLatency(2000);

                        //builder.setTriggerContentMaxDelay(100000);
                        builder.setPersisted(true);
                        jobInfo = builder.build();
                        jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                        jobScheduler.schedule(jobInfo);

                    }else{

                        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID,componentName);
                        builder.setPeriodic(2000);
                        builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
                        builder.setPersisted(true);
                        jobInfo = builder.build();
                        jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                        jobScheduler.schedule(jobInfo);
                    }


                    switch(db.department(acUsername.getText().toString(), etPassword.getText().toString()))
                    {
                        case "ES":
                            Intent intent = new Intent(this, ES.class);
                            startActivity(intent);
                            break;

                        case "MIK":
                            Intent intent2 = new Intent(this, MIK.class);
                            startActivity(intent2);
                            break;
                    }
                }
                else
                {
                    Toast.makeText(this, "Check your password and try again", Toast.LENGTH_SHORT).show();
                }
            }
            else
            {
                Toast.makeText(this, "Username does not exist in the database", Toast.LENGTH_SHORT).show();
            }

        }
    }

}

