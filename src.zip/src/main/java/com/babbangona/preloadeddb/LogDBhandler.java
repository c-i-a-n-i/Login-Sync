package com.babbangona.preloadeddb;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by ciani on 12/03/2018.
 */
public class LogDBhandler extends SQLiteOpenHelper {

    private static final String database = "LOGS_1.db";
    private static final String table = "Log1";
    private static final String timestamp = "timestamp";
    private static final String message = "message";
    private static final String status = "status";
    private static final String entity = "entity";
    private static final String action = "action";
    private static final String syncStatus = "syncStatus";
    private static final String updateStatus = "updateStatus";
    private static final String time = "time";
    private static final String date = "date";

    //Shared Preferences variables
    SharedPreferences prefs;
    String user, hub;
    Context context;    //used to getPreferences

    public LogDBhandler(Context context, SQLiteDatabase.CursorFactory factory) {
        super(context, database, factory, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create = "create table " + table + "(" + "id integer primary key autoincrement not null, "
                + timestamp + " timestamp, "
                + message + " text, "
                + status + " text, "
                + entity + " text, "
                + action + " text, "
                + time + " text, "
                + date + " text, "
                + syncStatus + " text, "
                + updateStatus + " text);";

        sqLiteDatabase.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop if table exists "+ table);
        onCreate(sqLiteDatabase);
    }

    public void onAdd(Logs log)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("timestamp", System.currentTimeMillis());
        values.put("message", log.getMessage());
        values.put("status", log.getStatus().name());
        values.put("entity", log.getEntity().name());
        values.put("action", log.getAction().name());
        values.put("time", log.getTime());
        values.put("date", log.getDate());
        values.put("syncStatus", "no");
        values.put("updateStatus", "no");
        db.insert(table, null, values);
        db.close();
    }


    //function that populates the array list that populates our array adapter. The function can be edited to display filtered or sorted values
    //based on status, entity and co. This can be done by adjusting the sql query "all" appropriately
    public ArrayList<Logs> displayByTimestamp()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByField()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"FIELD\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByMember()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"MEMBER\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByTG()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + entity + " = \"TG\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByAddtions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"ADD\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByEditions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"EDIT\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByDeletions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"DELETE\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByMerges()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"MERGE\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByRecalls()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + action + " = \"RECALL\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByUnuploaded()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"UNUPLOADED\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByUploaded()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"UPLOADED\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public ArrayList<Logs> displayByProcessed()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " where " + status + " = \"PROCESSED\" order by " + timestamp + " desc";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Logs> logs = new ArrayList<>();

        if(c.getCount() < 1){ return logs;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            logs.add(new Logs(c.getString(c.getColumnIndex("time")),c.getString(c.getColumnIndex("date")), Logs.Status.valueOf(c.getString(c.getColumnIndex("status"))), c.getString(c.getColumnIndex("message")), Logs.Entity.valueOf(c.getString(c.getColumnIndex("entity"))), Logs.Action.valueOf(c.getString(c.getColumnIndex("action")))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return logs;

    }

    public void onStatusUpdate(String id, String status)
    {
        SQLiteDatabase db = getWritableDatabase();
        String update = "update " + table + " set status = \"" + status + "\" where id = \"" + id + "\"";
        db.execSQL(update);
        db.close();

    }

    /*PHP and online functions
    .
    .
    .
    .
    .
     */
    public void updateSyncStatus(String id, String sync){
        String updateQuery = "update " + table + " set syncStatus = '"+ sync +"', status = 'UPLOADED' where id = "+ id;
        Log.d("query", updateQuery);
        Log.i("SUCCESS", updateQuery);
        getReadableDatabase().execSQL(updateQuery);
    }

    public ArrayList<HashMap<String, String>> getAllLogs(){
        ArrayList<HashMap<String, String>> wordList = new ArrayList<>();
        String selectQuery = "select * from " + table;
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);

        //gets the mik's name and hub to be appended to each log for identification of users
        prefs = context.getSharedPreferences("Preferences", MODE_PRIVATE);
        user = prefs.getString("username"," ");
        hub = prefs.getString("hub", " ");
        cursor.moveToFirst();
        if(cursor.getCount() < 1){ return wordList;}

        do
        {
            HashMap<String, String> map = new HashMap<>();
            map.put("id", cursor.getString(cursor.getColumnIndex("id")));
            map.put("user", user);
            map.put("hub", hub);
            map.put("timestamp", cursor.getString(cursor.getColumnIndex("timestamp")));
            map.put("message", cursor.getString(cursor.getColumnIndex("message")));
            map.put("status", cursor.getString(cursor.getColumnIndex("status")));
            map.put("entity", cursor.getString(cursor.getColumnIndex("entity")));
            map.put("action", cursor.getString(cursor.getColumnIndex("action")));
            map.put("time", cursor.getString(cursor.getColumnIndex("time")));
            map.put("date", cursor.getString(cursor.getColumnIndex("date")));
            map.put("syncStatus", cursor.getString(cursor.getColumnIndex("syncStatus")));
            map.put("updateStatus", cursor.getString(cursor.getColumnIndex("updateStatus")));
            wordList.add(map);
        }while (cursor.moveToNext());
        cursor.close();

        return wordList;
    }

    public ArrayList<HashMap<String, String>> getAllUnsyncedLogs(){
        ArrayList<HashMap<String, String>> wordList = new ArrayList<>();
        String selectQuery = "select * from " + table + " where syncStatus = 'no'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);

        //gets the mik's name and hub to be appended to each log for identification of users
        prefs = context.getSharedPreferences("Preferences", MODE_PRIVATE);
        user = prefs.getString("username"," ");
        hub = prefs.getString("hub", " ");

        cursor.moveToFirst();
        do
        {
            HashMap<String, String> map = new HashMap<>();
            map.put("id", cursor.getString(cursor.getColumnIndex("id")));
            map.put("user", user);
            map.put("hub", hub);
            map.put("timestamp", cursor.getString(cursor.getColumnIndex("timestamp")));
            map.put("message", cursor.getString(cursor.getColumnIndex("message")));
            map.put("status", cursor.getString(cursor.getColumnIndex("status")));
            map.put("entity", cursor.getString(cursor.getColumnIndex("entity")));
            map.put("action", cursor.getString(cursor.getColumnIndex("action")));
            map.put("time", cursor.getString(cursor.getColumnIndex("time")));
            map.put("date", cursor.getString(cursor.getColumnIndex("date")));
            map.put("syncStatus", cursor.getString(cursor.getColumnIndex("syncStatus")));
            map.put("updateStatus", cursor.getString(cursor.getColumnIndex("updateStatus")));
            wordList.add(map);
        }while (cursor.moveToNext());
        cursor.close();

        return wordList;
    }

    public int dbSyncCount()
    {
        int count;
        String selectQuery = "select * from " + table + " where syncStatus = '" + "no" + "'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        count = cursor.getCount();
        return count;
    }

    public String composeJSONfromSQLite()
    {
        ArrayList<HashMap<String, String>> unsynced = this.getAllUnsyncedLogs();
        Gson gson = new GsonBuilder().create();
        Log.i("SUCCESS","JSON composed "+ gson.toJson(unsynced));
        return gson.toJson(unsynced);
    }


}
