package com.babbangona.preloadeddb;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Date;
import java.sql.Time;

public class edit_member extends AppCompatActivity {
    AutoCompleteTextView acSeason1;
    AutoCompleteTextView acSeason2;
    AutoCompleteTextView acIK1;
    AutoCompleteTextView acMem1;
    AutoCompleteTextView acIK2;
    AutoCompleteTextView acMem2;
    TextView tvName;
    TextView tvAge;
    TextView tvVillage;
    TextView tvSex;
    TextView tvPhone;
    EditText etName;
    EditText etAge;
    EditText etVillage;
    EditText etPhone;
    Spinner spSex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_member);

        acSeason1 = (AutoCompleteTextView) findViewById(R.id.acSeason1);        acSeason1.setText("R18");
        acSeason2 = (AutoCompleteTextView) findViewById(R.id.acSeason2);        acSeason2.setText("R18");
        acIK1 = (AutoCompleteTextView) findViewById(R.id.acIK1);
        acIK2 = (AutoCompleteTextView) findViewById(R.id.acIK2);
        acMem1 = (AutoCompleteTextView) findViewById(R.id.acMem1);
        acMem2 = (AutoCompleteTextView) findViewById(R.id.acMem2);
        tvName = (TextView) findViewById(R.id.tvName);
        tvAge = (TextView) findViewById(R.id.tvAge);
        tvVillage = (TextView) findViewById(R.id.tvVillage);
        tvSex = (TextView) findViewById(R.id.tvSex);
        tvPhone = (TextView) findViewById(R.id.tvPhone);
        etName = (EditText) findViewById(R.id.etName);
        etAge = (EditText) findViewById(R.id.etAge);
        etVillage = (EditText) findViewById(R.id.etVillage);
        etPhone = (EditText) findViewById(R.id.etPhone);
        spSex = (Spinner) findViewById(R.id.spSex);

        //onclicklisteners for the first line of autocomplete text views that refresh their options based on previously selected fields
        String[] seasons = {"R17", "R18", "R19"};   //list of possible seasons
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, seasons);   //array adapter for acSeason1
        acSeason1.setAdapter(adapter);
        FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, fldDB.getIKs(acSeason1.getText().toString()));
        acIK1.setAdapter(adapter1);
        //setting OnItemClickListener for acSeason1 to refresh the values to be displayed in acMem1
        acIK1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, fldDB.getMembers(acSeason1.getText().toString(), acIK1.getText().toString()));
                acMem1.setAdapter(adapter);
            }
        });

        acSeason2.setAdapter(adapter);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, fldDB.getIKs(acSeason2.getText().toString()));
        acIK2.setAdapter(adapter2);
        acIK2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, fldDB.getMembers(acSeason2.getText().toString(), acIK2.getText().toString()));
                acMem2.setAdapter(adapter);
                acMem2.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                        if (editable.length() == 2) {
                            //checks the two IDs, if not equal, toasts "IDs do not tally, check and try again" if equal
                            //sets the various text views to display relevant information
                            String IK1 = acSeason1.getText().toString() + acIK1.getText().toString() + acMem1.getText().toString();
                            String IK2 = acSeason2.getText().toString() + acIK2.getText().toString() + acMem2.getText().toString();
                            if (!IK1.equals(IK2)) {
                                Toast.makeText(edit_member.this, "IDs do not tally, check and try again", Toast.LENGTH_LONG).show();
                            } else {
                                String season = acSeason2.getText().toString();
                                String IK = acIK2.getText().toString();
                                String member = acMem2.getText().toString();

                                FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
                                tvName.setText(fldDB.getName(season, IK, member));
                                tvAge.setText(fldDB.getAge(season, IK, member));
                                tvVillage.setText(fldDB.getVillage(season, IK, member));
                                tvSex.setText(fldDB.getSex(season, IK, member));
                                tvPhone.setText(fldDB.getPhone(season, IK, member));
                            }

                        }

                    }
                });
            }
        });

        //setting adapter for the crop
        String[] sex = {" ", "Male", "Female"}; //the space in front is to make the spinner display a blank in default
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sex);
        spSex.setAdapter(adapter3);
    }

    public void editMem_onClick(View v) {
        String IK1 = acSeason1.getText().toString() + acIK1.getText().toString() + acMem1.getText().toString();
        String IK2 = acSeason2.getText().toString() + acIK2.getText().toString() + acMem2.getText().toString();
        final String IK = acIK1.getText().toString();
        final String mem = acMem1.getText().toString();
        final String name = etName.getText().toString();
        final String age = etAge.getText().toString();
        final String village = etVillage.getText().toString();
        final String phone = etPhone.getText().toString();

        //Checks if the two IKs entered are equal
        if (!IK1.equals(IK2)) {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return;
        }

        //checks if there are any empty input fields
        if (IK.equals("") || mem.equals("") || name.equals("") || age.equals("") || village.equals("") || phone.equals("") || spSex.getSelectedItem() == null) {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return;
        }
        //these are declared after the above if block because otherwise if spSex is empty/null, it will give an error if toString() is called on it
        final String sex = spSex.getSelectedItem().toString();

        //checks if the confirmed member exists
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if (!db.memberExists(acIK1.getText().toString(), acMem1.getText().toString())) {
            Toast.makeText(getApplicationContext(), "Member " + IK1 + " does not exist in the database", Toast.LENGTH_LONG).show();
            return;
        }

        //Alert dialog that asks if the user is sure of his action
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Edit Member");
        builder1.setMessage("Are you sure you want to edit this member?");
        builder1.setIcon(android.R.drawable.ic_dialog_alert);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //getting current date and time and using them to initialize the log object
                        Date date = new Date(System.currentTimeMillis());
                        Time time = new Time(System.currentTimeMillis());
                        Logs log = new Logs(time.toString(), date.toString());

                        log.edit_member(IK, mem, name, age, village, sex, phone);
                        LogDBhandler db = new LogDBhandler(getApplicationContext(), null);
                        db.onAdd(log);
                        db.close();
                        Toast.makeText(getApplicationContext(), "Member scheduled for editing", Toast.LENGTH_LONG).show();
                        dialog.cancel();
                        Intent intent = new Intent(getApplicationContext(), MIK.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert = builder1.create();
        alert.show();

    }

    public boolean validInputs()
    {
        String IK1 = acSeason1.getText().toString() +"-"+ acIK1.getText().toString() +"-"+ acMem1.getText().toString();
        String IK2 = acSeason2.getText().toString() +"-"+ acIK2.getText().toString() +"-"+ acMem2.getText().toString();
        final String IK = acIK1.getText().toString();
        final String mem = acMem1.getText().toString();

        //Checks if the two IKs entered are equal
        if(!IK1.equals(IK2))
        {
            Toast.makeText(getApplicationContext(), "IDs do not match", Toast.LENGTH_LONG).show();
            return false;
        }

        //checks if there are any empty input fields
        if(IK.equals("") || mem.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Incomplete info, check inputs and try again", Toast.LENGTH_LONG).show();
            return false;
        }

        //checks if the confirmed field exists
        FieldDBHandler db = new FieldDBHandler(getApplicationContext());
        if(!db.memberExists(acIK1.getText().toString(), acMem1.getText().toString()))
        {
            Toast.makeText(getApplicationContext(), "Field " + IK1 + "  does not exist in the database", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    public void refresh_onClick(View v)
    {
        if(validInputs())
        {
            //refresh
            String season = acSeason1.getText().toString();
            String IK = acIK1.getText().toString();
            String member = acMem1.getText().toString();
            FieldDBHandler fldDB = new FieldDBHandler(getApplicationContext());
            tvName.setText(fldDB.getName(season, IK, member));
            tvAge.setText(fldDB.getAge(season, IK, member));
            tvVillage.setText(fldDB.getVillage(season, IK, member));
            tvSex.setText(fldDB.getSex(season, IK, member));
            tvPhone.setText(fldDB.getPhone(season, IK, member));
            Log.i("SUCCESS", "Text refreshed");
        }
        else
        {
            Toast.makeText(getApplicationContext(), "Invalid inputs, check input fields and try again", Toast.LENGTH_LONG).show();
        }

    }
}
