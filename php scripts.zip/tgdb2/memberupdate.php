<?php 

$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk", "CIANI");
	

$date = $_POST["lastMemUpdate"];
	
$a = array();
$b = array();

//Loop through an Array and insert data read from JSON into MySQL DB
$fetch = mysqli_query($con, "select * from members where timestamp > '$date'");

while($res = mysqli_fetch_array($fetch))
{
	$b["id"] = $res["id"];
	$b["timestamp"] = $res["timestamp"];
	$b["season_id"] = $res["season_id"];
	$b["ik_number"] = $res["ik_number"];
	$b["member_id"] = $res["member_id"];
	$b["first_name"] = $res["first_name"];
	$b["last_name"] = $res["last_name"];
	$b["sex"] = $res["sex"];
	$b["birthday"] = $res["birthday"];
	$b["village"] = $res["village"];
	$b["phone"] = $res["phone"];
	
	array_push($a,$b);
}

echo json_encode($a);
	
?>