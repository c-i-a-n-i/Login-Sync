<?php
//Get JSON pasted by Android application.

$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk","ciani");

$json = $_POST["unupdatedJSON"];

//Remove slashes

$json = stripslashes($json);

$data = json_decode($json);
//Utilize arrays to create response JSON

$a = array();
$b = array();

//Loop through an Array and insert data read from JSON into MySQL DB

for($i=0; $i<count($data); $i++)
{
	$res = mysqli_query($con, "update logs2 set status = 'PROCESSED' where idonline = '{$data[$i]->idonline}'");

	//this is to generate the array of id and syncStatus that updates the sync status of the local db
	if($res)
	{
		$b["idonline"] = $data[$i]->idonline;
		$b["updateStatus"] = 'yes';
		array_push($a,$b);
	}else
	{
		$b["idonline"] = $data[$i]->idonline;
		$b["updateStatus"] = 'no';
		array_push($a,$b);
	}
}

echo json_encode($a);

?>