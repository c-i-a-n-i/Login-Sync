<?php 

	$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk", "CIANI");
	
	$tmp = array();
	$hub = $_POST["hub"];
	
	$exe = mysqli_query($con, "select * from logs2 where hub = '$hub' and syncStatus = 'no'");
	
	while($row = mysqli_fetch_array($exe))
		{
			array_push($tmp, $row);
		}
	
	echo json_encode($tmp);	
	
	mysqli_query($con, "update logs2 set syncStatus = 'yes' where syncStatus = 'no'");	
	
	mysqli_close($con);
	
?>

