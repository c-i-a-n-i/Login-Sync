<?php
//Get JSON pasted by Android application.

$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk","ciani");

$json = $_POST["unsyncedJSON"];

//Remove slashes

$json = stripslashes($json);

$data = json_decode($json);
//Utilize arrays to create response JSON

$a = array();
$b = array();

//Loop through an Array and insert data read from JSON into MySQL DB

for($i=0; $i<count($data); $i++)
{
	$res = mysqli_query($con, "INSERT INTO logs2(id, user, hub, timestamp, message, status, entity, action, time, date, syncStatus, updateStatus)
	VALUES('{$data[$i]->id}', '{$data[$i]->user}', '{$data[$i]->hub}', '{$data[$i]->timestamp}','{$data[$i]->message}', '{$data[$i]->status}', '{$data[$i]->entity}', '{$data[$i]->action}', '{$data[$i]->time}', '{$data[$i]->date}', '{$data[$i]->syncStatus}', '{$data[$i]->updateStatus}')");

	//this is to generate the array of id and syncStatus that updates the sync status of the local db
	if($res)
	{
		$b["id"] = $data[$i]->id;
		$b["status"] = 'yes';
		array_push($a,$b);
	}else
	{
		$b["id"] = $data[$i]->id;
		$b["status"] = 'no';
		array_push($a,$b);
	}
}

echo json_encode($a);

?>