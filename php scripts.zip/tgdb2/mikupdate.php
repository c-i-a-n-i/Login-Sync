<?php 

	$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk", "CIANI");
	
	$user = $_POST["user"];
	
	$tmp = array();
	
	$exe = mysqli_query($con, "select * from logs2 where user = '$user' and updateStatus = 'no' and status = 'PROCESSED'");
	
	while($row = mysqli_fetch_array($exe))
		{
			array_push($tmp, $row);
		}
	
	echo json_encode($tmp);	
	
	mysqli_query($con, "update logs2 set updateStatus = 'yes' where user = '$user' and updateStatus = 'no' and status = 'PROCESSED'");	
	
	mysqli_close($con);
	
?>