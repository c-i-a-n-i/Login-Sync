<?php 

$con = mysqli_connect("localhost", "ciani", "LZJiwGrgSsEu1qrk", "CIANI");
	

$date = $_POST["lastFldUpdate"];
	
$a = array();
$b = array();

//Loop through an Array and insert data read from JSON into MySQL DB
$fetch = mysqli_query($con, "select * from fields where timestamp > '$date'");

while($res = mysqli_fetch_array($fetch))
{
	$b["id"] = $res["id"];
	$b["timestamp"] = $res["timestamp"];
	$b["season_id"] = $res["season_id"];
	$b["ik_number"] = $res["ik_number"];
	$b["member_id"] = $res["member_id"];
	$b["field_id"] = $res["field_id"];
	$b["size"] = $res["size"];
	$b["crop"] = $res["crop"];
	$b["crop_type"] = $res["crop_type"];
	$b["latitude"] = $res["latitude"];
	$b["longitude"] = $res["longitude"];
	array_push($a,$b);
}

echo json_encode($a);
	
?>